﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerRegister
{
    public abstract class PC
    {
        public int memory { get; set; }
        public string cpu { get; set; }

        public int yearOfMan { get; set; }


    }
}
